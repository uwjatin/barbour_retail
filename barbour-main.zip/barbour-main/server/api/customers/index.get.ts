import prisma from '~/server/db'

export default defineEventHandler(async (event) => {
  try {
    const customers = await prisma.customer.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    return {
      success: true,
      data: customers
    }
  } catch (error) {
    console.error('Error fetching customers:', error)
    return {
      success: false,
      error: 'Failed to fetch customers'
    }
  }
})
