import prisma from '~/server/db'

export default defineEventHandler(async (event) => {
  try {
    const products = await prisma.product.findMany({
      include: {
        variations: true,
        category: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    return {
      success: true,
      data: products
    }
  } catch (error) {
    console.error('Error fetching products:', error)
    return {
      success: false,
      error: 'Failed to fetch products'
    }
  }
})
