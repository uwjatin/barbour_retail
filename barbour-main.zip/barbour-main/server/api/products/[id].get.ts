import prisma from '~/server/db'

export default defineEventHandler(async (event) => {
  try {
    const { id } = getRouterParams(event)
    
    const product = await prisma.product.findUnique({
      where: { id },
      include: {
        variations: true,
        category: true
      }
    })
    
    if (!product) {
      return {
        success: false,
        error: 'Product not found'
      }
    }
    
    return {
      success: true,
      data: product
    }
  } catch (error) {
    console.error('Error fetching product:', error)
    return {
      success: false,
      error: 'Failed to fetch product'
    }
  }
})
