import prisma from '~/server/db'

export default defineEventHandler(async (event) => {
  try {
    const { status } = getQuery(event) as any
    
    const repairs = await prisma.repair.findMany({
      where: {
        status: status || undefined
      },
      include: {
        customer: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    return {
      success: true,
      data: repairs
    }
  } catch (error) {
    console.error('Error fetching repairs:', error)
    return {
      success: false,
      error: 'Failed to fetch repairs'
    }
  }
})
