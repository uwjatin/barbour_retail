import prisma from '~/server/db'

export default defineEventHandler(async (event) => {
  try {
    const method = event.method

    if (method === 'GET') {
      const { status, type, limit, offset } = getQuery(event) as any

      const where: any = {}
      if (status) where.status = status
      if (type) where.type = type

      const notifications = await prisma.notification.findMany({
        where,
        include: {
          order: true,
          repair: true,
          Customer: true
        },
        orderBy: {
          createdAt: 'desc'
        },
        take: limit ? parseInt(limit) : undefined,
        skip: offset ? parseInt(offset) : undefined
      })

      const total = await prisma.notification.count({
        where
      })

      return {
        success: true,
        data: notifications,
        total
      }
    }

    return {
      success: false,
      error: 'Method not allowed'
    }
  } catch (error) {
    console.error('Error fetching notifications:', error)
    return {
      success: false,
      error: 'Failed to fetch notifications'
    }
  }
})
