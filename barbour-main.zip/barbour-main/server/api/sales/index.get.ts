import prisma from '~/server/db'
import { Prisma } from '@prisma/client'

export default defineEventHandler(async (event) => {
  try {
    const query = getQuery(event)
    const startDate = query.startDate ? new Date(query.startDate as string) : null
    const endDate = query.endDate ? new Date(query.endDate as string) : null
    const type = query.type as string | undefined
    const productId = query.productId as string | undefined
    const limit = query.limit ? parseInt(query.limit as string) : 100
    const offset = query.offset ? parseInt(query.offset as string) : 0

    const where: any = {
      status: { not: 'cancelled' }
    }

    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) where.createdAt.gte = startDate
      if (endDate) where.createdAt.lte = endDate
    }

    if (type) {
      where.type = type
    }

    const orders = await prisma.order.findMany({
      where,
      include: {
        items: {
          include: {
            product: true
          }
        },
        customer: true
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: limit,
      skip: offset
    })

    const total = await prisma.order.count({
      where
    })

    const now = new Date()
    const sevenDaysAgo = new Date(now)
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const aggregatedSales = await prisma.$queryRaw(
      Prisma.sql`
        SELECT 
          p.id,
          p.name,
          p.type,
          COUNT(oi.id) as times_sold,
          SUM(oi.quantity) as total_quantity,
          SUM(oi.total) as total_revenue
        FROM order_items oi
        JOIN products p ON oi."productId" = p.id
        JOIN orders o ON oi."orderId" = o.id
        WHERE o.status != 'cancelled'
        AND o."createdAt" >= ${sevenDaysAgo}
        GROUP BY p.id, p.name, p.type
        ORDER BY total_quantity DESC
        LIMIT 50`
    )

    const salesByDay = await prisma.$queryRaw(
      Prisma.sql`
        SELECT 
          DATE(o."createdAt") as date,
          COUNT(DISTINCT o.id) as order_count,
          SUM(oi.quantity) as items_sold,
          SUM(oi.total) as daily_revenue
        FROM orders o
        JOIN order_items oi ON o.id = oi."orderId"
        WHERE o.status != 'cancelled'
        AND o."createdAt" >= ${sevenDaysAgo}
        GROUP BY DATE(o."createdAt")
        ORDER BY date DESC
        LIMIT 90`
    )

    const salesBySize = await prisma.$queryRaw(
      Prisma.sql`
        SELECT 
          oi.size,
          SUM(oi.quantity) as total_quantity,
          SUM(oi.total) as total_revenue
        FROM order_items oi
        JOIN orders o ON oi."orderId" = o.id
        WHERE o.status != 'cancelled'
        AND o."createdAt" >= ${sevenDaysAgo}
        GROUP BY oi.size
        ORDER BY total_quantity DESC`
    )

    const salesByColor = await prisma.$queryRaw(
      Prisma.sql`
        SELECT 
          oi.color,
          SUM(oi.quantity) as total_quantity,
          SUM(oi.total) as total_revenue
        FROM order_items oi
        JOIN orders o ON oi."orderId" = o.id
        WHERE o.status != 'cancelled'
        AND o."createdAt" >= ${sevenDaysAgo}
        GROUP BY oi.color
        ORDER BY total_quantity DESC`
    )

    const formatDecimal = (value: any) => {
      if (value === null || value === undefined) return 0
      return typeof value === 'object' ? parseFloat(value.toString()) : Number(value)
    }

    const formatBigInt = (value: any) => {
      if (value === null || value === undefined) return 0
      return typeof value === 'bigint' ? Number(value) : Number(value)
    }

    return {
      success: true,
      data: {
        orders,
        total: formatBigInt(total),
        aggregatedSales: aggregatedSales.map((item: any) => ({
          ...item,
          timesSold: formatBigInt(item.times_sold),
          totalQuantity: formatBigInt(item.total_quantity),
          totalRevenue: formatDecimal(item.total_revenue)
        })),
        salesByDay: salesByDay.map((item: any) => ({
          date: item.date,
          orderCount: formatBigInt(item.order_count),
          itemsSold: formatBigInt(item.items_sold),
          dailyRevenue: formatDecimal(item.daily_revenue)
        })),
        salesBySize: salesBySize.map((item: any) => ({
          size: item.size,
          totalQuantity: formatBigInt(item.total_quantity),
          totalRevenue: formatDecimal(item.total_revenue)
        })),
        salesByColor: salesByColor.map((item: any) => ({
          color: item.color,
          totalQuantity: formatBigInt(item.total_quantity),
          totalRevenue: formatDecimal(item.total_revenue)
        }))
      }
    }
  } catch (error) {
    console.error('Error fetching sales data:', error)
    return {
      success: false,
      error: 'Failed to fetch sales data'
    }
  }
})
