import prisma from '~/server/db'

export default defineEventHandler(async (event) => {
  try {
    const { productId, variationId, type, limit } = getQuery(event) as any
    
    const movements = await prisma.stockMovement.findMany({
      where: {
        productId: productId || undefined,
        variationId: variationId || undefined,
        type: type || undefined
      },
      include: {
        product: true
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: limit ? parseInt(limit) : 100
    })
    
    return {
      success: true,
      data: movements
    }
  } catch (error) {
    console.error('Error fetching stock movements:', error)
    return {
      success: false,
      error: 'Failed to fetch stock movements'
    }
  }
})
